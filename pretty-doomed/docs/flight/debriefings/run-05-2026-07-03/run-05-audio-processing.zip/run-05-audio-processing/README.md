# OPS-SAT PRETTY - Run 5 RF-link test (2026-07-03), audio processing

The spacecraft recorded six 2-second wideband raw IQ snapshots of a 1296 MHz uplink and downlinked them. There was no on-board audio; these WAV files are produced on the ground by processing that IQ different ways. The minimally processed rendering lives separately in the data folder's `run-05-raw-audio.zip`; this bundle holds the analysis and enhancement renderings.

**File naming:** `<HHMMSS>_<pass>.wav`, where `HHMMSS` is the capture start time (UTC) of the source recording `sdr_20260703_<HHMMSS>_1295500000_2500000_1.cs16`

- Pass 1 (19:2x): first pass, transmitting without an amplifier (worse case).
- Pass 2 (20:5x): second pass, with an amplifier.
- `192433_pass1` has no detectable carrier (taken before the signal was up); its files are essentially noise. The other five contain the transmission.

The folders are ordered from the least-processed rendering to the on-board pipeline output, its ground-denoised versions, the radio-amateur team's own processing, and the narrowed on-board chain. Each folder has its own README.

## Key point

The transmission is FM voice (confirmed by the operators, sent wide). The FM demod in the pipeline is the right one, but it is fed the full wide band, so the voice comes out as near-static. Narrowing to the signal bandwidth before the demod recovers it. The voice is recoverable on the ground but hard to make out, and the words cannot be identified with confidence. Run through the real on-board pipeline, the speech-to-text transcribed only noise fragments, not intelligible words.

## Best voice captures

The cleanest voice recovery overall is the radio-amateur team's own processing in `06_amateur_processed_voice/`. The best of our own attempts from the on-board FM pipeline audio is `05_onboard_fm_pipeline_denoised_thirdparty/192531_pass1_fm_denoised.mp3`. Both were produced on the ground with processing we cannot run on the spacecraft, so they show what is achievable in post-processing, not what the on-board pipeline can produce.

## Folders

1. **01_carrier_beat_tone** - carrier shifted to an audible tone; hear it key on and off, consistent with the antenna-rotation pauses. Not speech. All six snapshots.
2. **02_single_sideband_voice** - single-sideband demod, which narrows to one sideband; voice recovered. Five snapshots with a carrier.
3. **03_single_sideband_voice_denoised** - the single-sideband voice after noise reduction. Five snapshots.
4. **04_onboard_fm_pipeline** - what the on-board doom pipeline actually produces (FM demod). The audio the on-board speech-to-text ingests. All six.
5. **05_onboard_fm_pipeline_denoised_thirdparty** - three of the folder-04 snapshots after a third-party denoiser, as exported at source (MP3). The best of our own attempts. Ground only.
6. **06_amateur_processed_voice** - the radio-amateur team's own numpy/scipy processing and denoising; the cleanest voice recovery overall. All six.
7. **07_onboard_fm_narrowed** - the on-board FM chain with the issue #107 narrowing stage enabled (peak find, shift to DC, low-pass to ±10 kHz before the discriminator). Compare with folder 04 to hear the fix. All six.
