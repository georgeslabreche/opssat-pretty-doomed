# 07 On-board FM pipeline with the narrowing stage

The same on-board FM chain as folder 04, but with the narrowing stage from issue #107 enabled: find the strongest peak within ±100 kHz of the expected uplink, shift it to 0 Hz, low-pass to ±10 kHz and decimate before the unchanged FM discriminator. Produced with `tools/preview_onboard` (`narrow_bw_hz=20000`).

Compare with `../04_onboard_fm_pipeline`: the wide as-flown chain gives near-static, this narrowed chain gives voice. The words are still hard to make out on these 2 second snapshots, and no command is detected through the flight speech-to-text, but the speech structure is back.

Files are named `<HHMMSS>_<pass>.wav` (capture start time, UTC). `192433_pass1` is the noise-only snapshot.
