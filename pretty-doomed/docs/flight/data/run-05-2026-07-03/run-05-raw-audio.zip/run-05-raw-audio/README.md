# OPS-SAT PRETTY - Run 5 RF-link test (2026-07-03), raw audio

The spacecraft recorded six 2-second wideband raw IQ snapshots of a 1296 MHz uplink and downlinked them; the raw IQ itself is too large for the repo. These WAV files are the minimally processed listenable rendering of each snapshot: tune to the strongest signal and take a ±8 kHz slice with both sidebands, with no sideband selection, no voice band-pass, and no noise reduction. The most faithful listenable rendering of the transmission.

Files are named `<HHMMSS>_<pass>.wav`, where `HHMMSS` is the capture start time (UTC) and ties each WAV to its source recording `sdr_20260703_<HHMMSS>_1295500000_2500000_1.cs16` (for example `192433_pass1.wav` comes from the 19:24:33 UTC recording). Pass 1 (19:2x) was without an amplifier, pass 2 (20:5x) with one. `192433_pass1` was taken before the signal was up and is essentially noise; the other five contain the transmission.

The analysis and enhancement renderings (carrier tone, single-sideband voice, on-board pipeline output, denoised versions, the radio-amateur team's own processing, and the narrowed on-board chain) are in the debriefing's `run-05-audio-processing.zip`.
