# OPS-SAT PRETTY - Run 5 RF-link test (2026-07-03), ground-demodulated audio

The spacecraft recorded six 2-second wideband raw IQ snapshots of a 1296 MHz
uplink and downlinked them. There was no on-board audio; these WAV files are
produced on the ground by demodulating that IQ different ways.

**File naming:** `<UTC time>_<pass>.wav`

- Pass 1 (19:2x): first pass, transmitting without an amplifier (worse case).
- Pass 2 (20:5x): second pass, with an amplifier.
- `192433_pass1` has no detectable carrier (taken before the signal was up); its files are essentially noise. The other five contain the transmission.

The folders are ordered from the least-processed rendering of the signal to the
on-board pipeline output and its ground-denoised version. Each folder has its
own README.

## Key point

The transmission is FM voice (confirmed by the operators, sent wide). The FM
demod in the pipeline is the right one, but it is fed the full wide band, so the
voice comes out as near-static. Narrowing to the signal bandwidth before the
demod recovers it. The voice is recoverable on the ground but hard to make out,
and the words cannot be identified with confidence. Run through the real on-board
pipeline, the speech-to-text transcribed only noise fragments, not intelligible
words.

## Best voice capture

`06_onboard_fm_pipeline_denoised_thirdparty/192531_pass1_fm_denoised.mp3` is our
clearest voice capture so far. It was denoised on the ground with a third-party
tool that we will not be able to run on the spacecraft, so it shows what is
achievable in post-processing, not what the on-board pipeline can produce.

## Folders

1. **01_raw_minimal** - minimal processing, both sidebands, no filtering. The most faithful rendering of what is in the band. All six snapshots.
2. **02_carrier_beat_tone** - carrier shifted to an audible tone; hear it key on and off with the antenna-rotation pauses. Not speech. All six.
3. **03_single_sideband_voice** - single-sideband demod, which narrows to one sideband; voice recovered. Five snapshots with a carrier.
4. **04_single_sideband_voice_denoised** - the single-sideband voice after noise reduction. Five snapshots.
5. **05_onboard_fm_pipeline** - what the on-board doom pipeline actually produces (FM demod). The audio the on-board speech-to-text ingests. All six.
6. **06_onboard_fm_pipeline_denoised_thirdparty** - three of the folder-05 snapshots after a third-party denoiser, as exported at source (MP3). Contains our best voice capture. Ground only.
