# 01 Raw minimal

Minimal-processing rendering of each snapshot: tune to the transmission and take
both sidebands, with no sideband selection, no voice band-pass, and no noise
reduction. This is the most faithful rendering of what is in the band.

Files are `<UTC time>_<pass>.wav`. Pass 1 (19:2x) was without an amplifier,
pass 2 (20:5x) with one. `192433_pass1` was taken before the signal was up and
is essentially noise; the other five contain the transmission.
