# 06 On-board FM pipeline, third-party denoised

Three on-board FM pipeline snapshots after an external third-party denoiser,
as exported by the tool at source (MP3, 48 kHz):

- `192511_pass1_fm_denoised.mp3`
- `192531_pass1_fm_denoised.mp3` - our clearest voice capture so far
- `205727_pass2_fm_denoised.mp3`

The un-denoised originals are the corresponding files in `../05_onboard_fm_pipeline`
(`192511_pass1.wav`, `192531_pass1.wav`, `205727_pass2.wav`); compare against
those to hear what the denoiser does.

The denoiser was run on the ground, off-board. Its behavior is that of a learned
speech denoiser: it drives the broadband noise floor to near silence and keeps
smooth, voice-shaped time-frequency regions. This is not something we can run on
the spacecraft, so treat these as what post-processing can achieve, not what the
on-board pipeline produces.
