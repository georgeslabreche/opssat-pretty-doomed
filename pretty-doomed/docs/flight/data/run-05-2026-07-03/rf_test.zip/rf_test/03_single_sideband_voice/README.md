# 03 Single-sideband voice

The snapshots demodulated as single sideband, which narrows to one sideband and
recovers the voice. The words are hard to make out and cannot be identified with
confidence, but it is clearly speech and not a tone. Compare with
`../05_onboard_fm_pipeline`: the transmission is FM, so its FM demod is the right
one, but folder 05 is fed the full wide band and comes out as static, while
narrowing here brings the voice back. Narrowing is the lever, not the demod type.

Files are `<UTC time>_<pass>.wav`, for the five snapshots that contain a carrier.
