# 04 Single-sideband voice, denoised

The single-sideband voice from folder 03 after spectral-subtraction noise
reduction, run on the ground. Provided to hear the voice a little more clearly;
it is not what the on-board pipeline produces.

Files are `<UTC time>_<pass>.wav`, for the five snapshots that contain a carrier.
