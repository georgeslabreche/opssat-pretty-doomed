# 05 On-board FM pipeline

What the on-board doom pipeline actually produces: the exact flight DSP chain
(FM demodulation) applied to each snapshot. This is the audio the on-board
speech-to-text ingests. The transmission is FM, so this FM demod is the right
one, but the discriminator is fed the full wide band, so the voice comes out as
near-static and the transcriber returns only noise fragments, not intelligible
words.

Compare with `../03_single_sideband_voice`: narrowing to the signal bandwidth
before demodulating is what brings the voice back. The gap is bandwidth, not the
demod type.

Files are `<UTC time>_<pass>.wav`. `192433_pass1` is the noise-only snapshot;
the other five contain the transmission.
