# 07 Amateur-processed voice (LA4O)

The radio-amateur team's own processing and denoising of the Run 5 signal, using
numpy and scipy, one file per snapshot. Named for the Oslo team's call sign LA4O
("lima alfa four oscar"). This is the cleanest voice recovery we have; the speech
is clearly intelligible by ear.

Files are `<UTC time>_<pass>.wav` (16 kHz mono, 2 s). `192433_pass1` is the
snapshot taken before the signal was up, so it is essentially noise; the other
five contain the transmission, which included the call sign and "play doom".

Note: when these are run through the same speech-to-text pipeline that runs on
board, the command is still not detected. Good, human-intelligible audio is not
the same as audio the on-board recognizer can read.
