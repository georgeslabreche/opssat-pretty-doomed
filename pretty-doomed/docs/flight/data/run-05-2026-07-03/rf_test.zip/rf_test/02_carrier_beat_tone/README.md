# 02 Carrier beat tone

Each snapshot with the carrier shifted to an audible beat tone. You hear the
carrier switch on and off, matching the operators' pauses to rotate the antenna.
This is not speech; it is the clearest way to confirm the carrier is present and
keying.

Files are `<UTC time>_<pass>.wav`. `192433_pass1` is the noise-only snapshot;
the other five contain the transmission.
